from sqlalchemy.orm import declarative_base

# Single Base for all ORM models
Base = declarative_base()
