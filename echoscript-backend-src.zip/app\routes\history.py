# app/routes/assistant.py

from fastapi import APIRouter

router = APIRouter()

# All AI assistant routes removed
# You can reintroduce endpoints here when needed


__all__ = []
