// Single source of truth for i18n.
// Re-export the configured instance from i18n.js to avoid double initialization.
export { default } from "./i18n";
