# app/core/settings.py
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Load .env and ignore any extra keys so startup never fails
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # (Optional) Common fields you actually use elsewhere in code.
    # If any of these aren't in your .env, the defaults below are used.
    env: str = "development"
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    cors_origins: Optional[str] = None
    allow_origins: Optional[str] = None

    # Auth / JWT
    secret_key: Optional[str] = None
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    jwt_secret_key: Optional[str] = None
    jwt_algorithm: str = "HS256"

    # Stripe
    stripe_secret_key: Optional[str] = None
    stripe_webhook_secret: Optional[str] = None
    stripe_public_key: Optional[str] = None
    stripe_price_pro: Optional[str] = None
    stripe_price_premium: Optional[str] = None

    # ASR / ML
    asr_model: Optional[str] = None
    whisper_model_size: Optional[str] = None
    whisper_device: Optional[str] = None
    whisper_compute: Optional[str] = None
    huggingface_token: Optional[str] = None
    pyannote_pipeline: Optional[str] = None
    openai_api_key: Optional[str] = None

    # Email / misc
    from_email: Optional[str] = None
    vite_api_base: Optional[str] = None
    smtp_key: Optional[str] = None

settings = Settings()
