import React from "react";

export default function SearchResults() {
  return (
    <div style={{padding:16}}>
      <h1>Search</h1>
      <p>Search results page placeholder.</p>
    </div>
  );
}